<?php
$conn = mysqli_connect('localhost', 'root', '',"trading") or die("Database Connection failed.");
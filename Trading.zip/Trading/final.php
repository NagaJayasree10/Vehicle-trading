<!DOCTYPE html>
<head>
<style>
body{
    background-color: black;
    color: white;
    padding-left: 400px;
    
}
.text{
   
    padding-top: 20px;
}
.img{
    border-radius: 20px;
    padding-left: 20px;
   
}
.button{
    
     font-size: larger;
     padding-top: 30px;
     padding-left: 230px;
    
 
}
.button a{
    color: white;
    text-decoration: none;
}
.main{
    border: 10px solid violet;
    padding: 50px;
    width: 520px;
    height: 600px;
   

}
</style>
  
</head>
<body>
<div class="main">
 <div class="text"> <h1> Money will be automatically detected </h1>
 </div>
 <div class="img"> <img src="https://images-na.ssl-images-amazon.com/images/I/61hfWhj5lAL._SX466_.jpg">
 </div>
 <div class="button"><a href="home.php"><button> HOME </button> </a>
 </div>
</div> 
</body>
</html>